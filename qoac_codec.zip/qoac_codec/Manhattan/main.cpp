#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <float.h>
#include <time.h>
#include <math.h>
#include <iostream>
using namespace std;
#include "share.h"

const bool ccson = false;
const int A=4, B=3, Q=A*B, K=Q+B-1;
//const int n=73, k=int(ceil(n*log2(K/double(B))/log2(double(Q)))), t = 5;
const int n=353, k=int(floor(n*log2(K/double(B))/log2(double(Q)))), t = 5;
const double b = .95*(n*(k+t))/double((n+t)*k);  // sigma = sqrt(2)*b
const int nef = (1<<8);

double **readccs(FILE *fp_ccs, int &nccs, int &t, int &nseg){
    double nccsf; fscanf(fp_ccs, "%lf", &nccsf); nccs = int(nccsf);    // number of CCSs
    double tf; fscanf(fp_ccs, "%lf", &tf); t = int(tf);    // tail length
    double nsegf; fscanf(fp_ccs, "%lf", &nsegf); nseg = int(nsegf);    // number of cells
 
    double **ccs = new double*[nccs+1];
    for(int i=0; i<=nccs; i++){
        ccs[i] = new double[nseg];
        for(int j=0; j<nseg; j++){
            fscanf(fp_ccs, "%lf", &ccs[i][j]);
            ccs[i][j] = log(ccs[i][j]);///M_LN2;
        }
    }
    return ccs;
}

//void print_settings(int n, int t, int nccs, int nseg, int seed, int nts){
//    cout<<"************************ Configurations **********************"<<endl;
//    cout<<"Code Length: "<<n<<endl;
//    cout<<"Tail Length: "<<t<<endl;
//    cout<<"Number of CCS: "<<nccs<<endl;
//    cout<<"Number of Segments: "<<nseg<<endl;
//    cout<<"Number of Tests: "<<nts<<endl;
//    cout<<"Seed: "<<seed<<endl;
//    cout<<"******************** End of Configurations *******************"<<endl<<endl;
//}

int main(int argc, char *argv[]){
//    int nccs = 0, nseg = 0;
//    double **ccs = NULL;
//    FILE *fp_ccs = fopen("ccs.txt", "rt");
//    if(!fp_ccs){
//        cout<<"CCS File Open Fail!"<<endl; return 1;
//    }else{
//        ccs = readccs(fp_ccs, nccs, t, nseg);
//        fclose(fp_ccs);
//    }
//    print_settings(n, t, nccs, nseg, seed, nef);
    
    cout<<"k="<<k<<endl;
        
    for(int M=1024; M<=1024; M*=2){
#ifndef OUTPUT
        cout<<"M = "<<M<<endl;
        clock_t start = clock();
#endif
        entry(n, t, nef, M);
#ifndef OUTPUT
        clock_t end = clock();
        cout<<(end-start)/CLOCKS_PER_SEC<<"s"<<endl;
#endif
    }
    return 0;
}

