#include <stdio.h>
#define OUTPUT
//#define REVERSE

#define bef(p)	(((p)*(1-(p))==0.0) ? (0.0):((-(p)*log2(p)-(1-(p))*log2(1-(p))))) // binary entropy function

// parameters to control the AC codec
const int      WIDTH = 32;
const unsigned HRNG = (1<<(WIDTH-1));    // half range
const unsigned QRNG = (1<<(WIDTH-2));    // quarter range
const unsigned MASK = ((HRNG-1)+HRNG);  // range-1

extern const bool ccson;
extern const int A, B, Q, K;    // Q=A*B, K=Q+B-1
extern const double b;  // scale parameter

struct NODE{
	unsigned low, high, code;
    int ptr;
    double u;       // self-projection of DAC bitstream
    unsigned exm;   // extrinsic metric
    double met;     // overall metric
    uint8_t x;
	NODE *parent, *child[16];
};
struct INTERVAL{double l; double h;};

int compress(uint8_t *str, const uint8_t *src, int n, int t);
int expand_bfd(uint8_t *rec, uint8_t *str, uint8_t *side, int n, int t, int M, double **ccs=NULL, int nccs=0, int nseg=0);
void create_bfd(int n, int M);
void delete_bfd(void);
int entry(int n, int t, int nef, int M, double **ccs=NULL, int nccs=0, int nseg=0);
