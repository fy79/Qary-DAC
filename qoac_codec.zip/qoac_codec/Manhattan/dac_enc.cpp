#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "share.h"

// encode one source symbol
void encode_symbol(uint8_t *str, unsigned &low, unsigned &high, int &nuf, int &ptr, uint8_t x, bool body){
    double lambda, eta;
    if(body){
#ifdef REVERSE
        lambda = (floor(x/A)+B*(A-1-(x%A)))/double(Q+B-1);
        eta = (floor(x/A)+B*(A-1-(x%A))+B)/double(Q+B-1);
#else
        lambda = (floor(x/A)+B*(x%A))/double(Q+B-1);
        eta = (floor(x/A)+B*(x%A)+B)/double(Q+B-1);
#endif
    }else{
        lambda = x/double(Q);
        eta = (x+1)/double(Q);
    }
    
    unsigned range = (high-low);
    high = low + unsigned(range*eta+eta-0.5);
    low += unsigned(range*lambda+lambda+0.5);

	/* If this test passes, the MSDigits match and can be sent to the output stream. */
    while(!((low^high)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(nuf){
            str[ptr++] = (low<HRNG);
            nuf--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }

	/* If this test passes, the numbers are in danger of underflow. */
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG;	low  <<= 1;
        high -= QRNG;	high <<= 1;	high |= 1;
		nuf++;
	}
}

// str <= src
int compress(uint8_t *str, const uint8_t *src, int n, int t){
	unsigned low = 0, high = MASK;
	int nuf = 0, ptr = 0;
    memset(str, 0, 8*(n+t)*sizeof(uint8_t));
    for(int i=0; i<(n+t); i++){
        encode_symbol(str, low, high, nuf, ptr, src[i], (i<n));
    }
	str[ptr] = 1;
	return ptr;
}
