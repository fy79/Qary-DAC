#include <stdio.h>
#define OUTPUT

#define bef(p)	(((p)*(1-(p))==0.0) ? (0.0):((-(p)*log(p)-(1-(p))*log(1-(p)))/log(2))) // binary entropy function
#define _bittest(BitBase, BitPos) (((*(BitBase))>>(BitPos))&1)

// parameters to control the AC codec
const int      ACBITS = 32;
const unsigned HRANGE = (1<<(ACBITS-1));    // half range
const unsigned QRANGE = (1<<(ACBITS-2));    // quarter range
const unsigned MASK = ((HRANGE-1)+HRANGE);  // range-1

extern const bool ccson;
extern const int A, B, Q, K;    // Q=A*B, K=Q+B-1
extern const double b;  // scale parameter

struct NODE{
	unsigned low, high, code;
    int ptr;
    double u;   // self-projection of DAC bitstream
    unsigned exm; // extrinsic metric
    double met; // overall metric
    uint8_t x;
	NODE *parent, *child[16];
};
struct INTERVAL{double l; double h;};

int compress(uint8_t *str, const uint8_t *src, int n, int t);
int expand_bfd(uint8_t *rec, uint8_t *str, uint8_t *side, int n, int t, int M, double **ccs=NULL, int nccs=0, int nseg=0);
void create_bfd(int n, int M);
void delete_bfd(void);
int entry(int n, int t, int nef, int M, double **ccs=NULL, int nccs=0, int nseg=0);
