#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <iostream>
using namespace std;
#include "share.h"

// encode one source symbol
void encode_symbol(uint8_t *str, unsigned &low, unsigned &high, int &nuf, int &ptr, uint8_t x, bool normal){
    double lambda, eta;
    if(normal){
        lambda = (floor(x/A)+B*(x%A))/(Q+B-1);
        eta = (floor(x/A)+B*(x%A)+B)/(Q+B-1);
    }else{
        lambda = x/double(Q);
        eta = (x+1)/double(Q);
    }
    
    unsigned range = (high-low);
    high = low + unsigned(ceil(range*eta+eta)) - 1;
    low += unsigned(ceil(range*lambda+lambda));

	/* If this test passes, the MSDigits match and can be sent to the output stream. */
    while(1){
        uint8_t msbh = _bittest(&high, ACBITS-1), msbl = _bittest(&low, ACBITS-1);
        if(msbh==msbl){
            str[ptr++] = msbl;
            low <<= 1; high <<= 1; high |= 1;
            while(nuf){
                str[ptr++] = !msbl;
                nuf--;
            }
        }else break;
    }
//    low &= MASK; high &= MASK;

	/* If this test passes, the numbers are in danger of underflow. */
	while(_bittest(&high, ACBITS-2) < _bittest(&low, ACBITS-2)){
		low  -= QRANGE;	low  <<= 1;
		high -= QRANGE;	high <<= 1;	high |= 1;
		nuf++;
	}
//    low &= MASK; high &= MASK;
}

// str <= src
int compress(uint8_t *str, const uint8_t *src, int n, int t){
	unsigned low = 0, high = MASK;
	int nuf = 0, ptr = 0;
    memset(str, 0, 8*(n+t)*sizeof(uint8_t));
    for(int i=0; i<(n+t); i++){
        encode_symbol(str, low, high, nuf, ptr, src[i], (i<n));
    }
	str[ptr] = 1;
	return ptr;
}
