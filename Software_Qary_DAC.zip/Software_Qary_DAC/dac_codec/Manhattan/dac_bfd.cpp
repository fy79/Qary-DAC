#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include <iostream>
#include <vector>
using namespace std;
#include "share.h"

static NODE **paths=NULL, *nodes=NULL;
static int nNodes, nPaths;

static NODE *create_root(uint8_t *str){
	NODE *root = &nodes[nNodes++];
	root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
	for(int i=0; i<ACBITS; i++){
		root->code <<= 1;
        root->code |= str[root->ptr++];
    }
	root->u = ((root->code) - (root->low))/((root->high) - (root->low) + 1.0);
    root->exm = 0U;
	root->parent = NULL;
    for (int i=0; i<B; i++) {
        root->child[i] = NULL;
    }
	return root;
}

static void renew_interval(uint8_t *str, unsigned &low, unsigned &high, unsigned &code, int &ptr, uint8_t x, bool normal){
    double lambda, eta;
    if(normal){
        lambda = (floor(x/A)+B*(x%A))/(Q+B-1);
        eta = (floor(x/A)+B*(x%A)+B)/(Q+B-1);
    }else{
        lambda = x/double(Q);
        eta = (x+1)/double(Q);
    }    
    
    unsigned range = (high-low);
    high = low + unsigned(ceil(range*eta+eta)) - 1;
    low += unsigned(ceil(range*lambda+lambda));

	while(_bittest(&high, ACBITS-1)==_bittest(&low, ACBITS-1)){
        low  <<= 1; //low &= MASK;
        high <<= 1;	high |= 1; //high &= MASK;
        code <<= 1; code |= str[ptr++]; //code &= MASK;
    }
	while(!_bittest(&high, ACBITS-2) && _bittest(&low, ACBITS-2)){
		low  -= QRANGE;	low  <<= 1;
		high -= QRANGE;	high <<= 1;	high |= 1;
        code -= QRANGE;	code <<= 1; code |= str[ptr++];
    }
//    low &= MASK; high &= MASK; code &= MASK;
}

static NODE *create_child(NODE *parent, uint8_t *str, uint8_t x, uint8_t y, int mode, double *ccs=NULL, int nseg=0){
    NODE *child = &nodes[nNodes++];
    memcpy(child, parent, 4*sizeof(int));// (low, high, code, ptr)
	renew_interval(str, child->low, child->high, child->code, child->ptr, x, (mode<2));
	child->u = ((child->code) - (child->low))/((child->high) - (child->low) + 1.0);
    child->exm = (parent->exm) + abs(int(x)-int(y));

    double inm;
    if ((child->u)<(B-1.0)/K) {
        inm = (K*K/double(Q*(B-1))) * (child->u);
    }else if ((child->u)<(Q/double(K))){
        inm = K/double(Q);
    }else{
        inm = (K*K/double(Q*(B-1))) * (1-(child->u));
    }
    child->met = (child->exm) - ccson*(mode<1)*(b*log(inm)); // overall metric
    
    child->x = x;
    child->parent = parent;
//    for (int i = 0; i < B; i++) {
//        child->child[i] = NULL;
//    }
    parent->child[int(x/A)] = child;
	return child;
}

static void extend(uint8_t *str, uint8_t y, int mode, int M, double *ccs=NULL, int nseg=0){
    int nChilds = nPaths;
	for(int j=0; j<nPaths; j++){
        if(mode<2){
            int x = int((paths[j]->u)*(Q+B-1));
            int lb = max(0,x-Q+1), ub = min(B,x+1);
            for(int k=lb; k<(ub-1); k++){
               paths[nChilds++] = create_child(paths[j], str, floor((x-k)/B)+(k*A), y, mode, ccs, nseg);
            }
            paths[j] = create_child(paths[j], str, floor((x-(ub-1))/B)+((ub-1)*A), y, mode, ccs, nseg);
        }else{
            int x = int((paths[j]->u)*Q);
            paths[j] = create_child(paths[j], str, x, y, mode, ccs, nseg);
        }
    }
	nPaths = nChilds;
}

static void traceback(uint8_t *rec, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        rec[i] = (now->x);
        now = (now->parent);
    }
}

static int compare(const void *a, const void *b){
    return ((*(NODE**)a)->met) - ((*(NODE**)b)->met);
}

int expand_bfd(uint8_t *rec, uint8_t *str, uint8_t *side, int n, int t, int M, double **ccs, int nccs, int nseg){
    nNodes = 0; nPaths = 0;
	paths[nPaths++] = create_root(str);
    for(int i=0; i<(n+t); i++){
        extend(str, side[i], (i>=n)+(i>=(n-1)), M);
        if(i<(n-1)){
            qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
            nPaths = min(nPaths,M);
        }
	}
    for(int j=1; j<nPaths; j++){
        if((paths[j]->met) < (paths[0]->met)){
            paths[0] = paths[j];
        }
    }
    traceback(rec, paths[0], (n+t));
	return nNodes;
}

void create_bfd(int n, int M){
    nodes = new NODE[(n*B*M)+1];
    paths = new NODE*[(B*M)+1];
}

void delete_bfd(void){
    if(paths)   delete[] paths;
    if(nodes)   delete[] nodes;
}
