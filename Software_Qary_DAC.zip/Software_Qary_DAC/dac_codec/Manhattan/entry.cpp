#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <float.h>
#include <time.h>
#include <math.h>
#include <iostream>
using namespace std;
#include "share.h"

// calculate Manhattan error
int get_me(const uint8_t *rec, const uint8_t *src, int n){
	int me = 0;
	for(int i=0; i<n; i++){
        me += abs(int(rec[i])-int(src[i]));
	}
	return me;
}

// generate source and side information
void gensrcside(uint8_t *src, uint8_t *side, int n){
	for(int i=0; i<n; i++){
        src[i] = (rand()&(Q-1));
        double y = src[i] + b * (log(rand()/double(RAND_MAX)) - log(rand()/double(RAND_MAX)));
        if(y<0){
            side[i] = 0;
        }else if(y>(Q-1)){
            side[i] = (Q-1);
        }else{
            side[i] = uint8_t(round(y));
        }
	}
}

int entry(int n, int t, int nef, int M, double **ccs, int nccs, int nseg){
	uint8_t *src = new uint8_t[11*(n+t)], *side = src+(n+t), *rec = side+(n+t), *str = rec+(n+t);
    create_bfd(n+t, M);// breadth-first
	
    int nts = 0;    // number of tests
	double bps = 0.0, mme = 0.0, fer = 0.0, mnn = 0.0; // bps: bits/sym; mme: mean Manhattan error; fer: frame-error-rate; mnn: mean num of nodes
//    srand(0); //srand((unsigned)_rdtsc());
    while(1){
        nts++;
		gensrcside(src, side, n+t);
		bps += compress(str, src, n, t);// str <= src
        mnn += expand_bfd(rec, str, side, n, t, M, ccs, nccs, nseg);// rec <= (str+side)
		int me = get_me(rec, src, n+t);
		mme += me;
        fer += (me>0);
        if(int(fer)>=nef){
            break;
        }
	}
    bps /= ((n+t)*nts); mme /= ((n+t)*nts); fer /= nts; mnn /= ((n+t)*nts);

#ifndef OUTPUT
    cout<<"************************ Results **********************"<<endl;
    cout<<"bps: "<<bps<<endl<<"MME: "<<mme<<endl<<"FER: "<<fer<<endl<<"MNN: "<<mnn<<endl;
    cout<<"******************** End of Results *******************"<<endl<<endl;
#else
    cout<<showpoint<<bps<<",\t"<<mme<<",\t"<<fer<<",\t"<<mnn<<";"<<endl;
#endif
  
    delete[] src;
    delete_bfd();

	return nts;
}
