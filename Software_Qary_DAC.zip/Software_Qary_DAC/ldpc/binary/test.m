clc; clear;
addpath codes;

%% field order of source symbol
q = 8;
Q = 2^q;

%% get code structure
% [rc, cr, rw, cw, rN, cN] = loadTG('reg3.2840.1456.txt');
% b = 2.7 * 353*182/(355*180); % scale parameter

[rc, cr, rw, cw, rN, cN] = loadTG('reg3.600.320.txt');
b = 2.4 * 73*40/(75*38); % scale parameter

nq = size(cr,1);
n = nq/q;

%% multicores
cls = parcluster;
pool = gcp;
if isempty(pool)
    pool = parpool(cls.NumWorkers);
end
nw = pool.NumWorkers;   % number of workers

%% statistical quantities
aln = zeros(1,nw);  % average loop number
mme = zeros(1,nw);  % mean Manhattan error
fer = zeros(1,nw);  % frame-error-rate
nts = zeros(1,nw);  % number of tests
NEF = 25;

rng('default');
tic;
parfor c=1:nw
    while 1
        x = randi(Q,[n,1]) - 1;         % uniformly-distributed Q-ary sources block
        z = b .* (log(rand(n,1)) - log(rand(n,1))); % additive noise
        y = min(Q-1, max(0, round(x+z)));   % side information

        xb = reshape(de2bi(x,q)',[nq,1]);   % x => xb (all bitplanes)
        s = enc(xb,rw,rc);  % xb => s (syndrome)
        [xr,~,loop] = dec(Q, b, y, s, rc, cr, rw, cw, cN, 0);

        err = mae(xr-x);
        mme(c) = mme(c) + err;
        fer(c) = fer(c) + (err>0);
        aln(c) = aln(c) + loop;
        nts(c) = nts(c) + 1;        
        if fer(c)>=NEF
            break;
        end    
    end
end
toc;

disp(sum(mme)/sum(nts));
disp(sum(fer)/sum(nts));
disp(sum(aln)/sum(nts));