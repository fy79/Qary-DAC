function [rc, cr, rw, cw, rN, cN] = loadTG(file)
% load Tanner Graph of the LDPC code specified by file
rc = load(file);    % row-col
[m,rwmax] = size(rc);   % m: number of check nodes; rwmax: max degree of check nodes
rw = sum(rc>0,2);   % degrees of check nodes
n = max(max(rc));   % numde of variable nodes
cw = zeros(n,1);    % degrees of variable nodes
for i=1:n
    cw(i) = sum(sum(rc==i));
end
cwmax = max(cw);    % max degree of variable nodes

cnt = zeros(n,1);   % temporary array
rN = zeros(m,rwmax);
cN = zeros(n,cwmax);
cr = zeros(n,cwmax); % col-row
for j=1:m
    for k=1:rw(j)
        i = rc(j,k);
        cnt(i) = cnt(i) + 1;
        rN(j,k) = cnt(i);
        cr(i,cnt(i)) = j;
        cN(i,cnt(i)) = k;
    end
end