function pmfQ = pmfb2Q(pmfb,Q)
% convert binary probability distribution to Q-ary probability distribution
q = log2(Q);
n = size(pmfb,1)/q;
pmfQ = ones(n,Q);
for k=1:q
    bitk = bitget(0:(Q-1),k);
    for i=1:n
        pmfQ(i,:) = pmfQ(i,:) .* pmfb((i-1)*q+k,bitk+1);
    end
end