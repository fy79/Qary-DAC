function s = enc(xb,rw,rc)
mq = length(rw);
s = zeros(mq,1);
for j=1:mq
    k = 1:rw(j);
    s(j) = mod(sum(xb(rc(j,k))),2);
end