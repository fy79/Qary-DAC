function pmfb = pmfQ2b(pmfQ)
% convert Q-ary probability distribution to binary probability distribution
[n,Q] = size(pmfQ);
q = log2(Q);
pmfb = zeros(n*q,2);
for k=1:q
    bitk = bitget(0:(Q-1),k);
    for i=1:n
        pmfb((i-1)*q+k,1) = sum(pmfQ(i,bitk==0));  % p0
        pmfb((i-1)*q+k,2) = sum(pmfQ(i,bitk==1));  % p1
    end
end


