function [xr, mode, loop] = dec(Q, b, y, s, rc, cr, rw, cw, cN, lb)
% b: scale parameter
% y: side information
% s: syndrome
% lb: lower bound for laplacian initialization

%% get parameters
q = log2(Q);
n = length(y);
nq = n*q;
mq = length(s);
rwmax = max(rw);
cwmax = max(cw);

%% syndrome check
xr = y;
xbr = reshape(de2bi(xr,q)',[nq,1]);
if all(s==enc(xbr,rw,rc))
    mode = 0;  
    loop = 0;
    return;
end

%% initialization
inpmfQ = initl(b,y,Q,lb);
inpmfb = pmfQ2b(inpmfQ);
qa = zeros(mq,rwmax,2); % into check
ra = zeros(mq,rwmax,2); % outof check 
for i=1:nq 
    for k=1:cw(i)
        qa(cr(i,k),cN(i,k),:) = inpmfb(i,:);
    end
end
cRa = zeros(cwmax,2);

%% iterations
nss = 0;
for loop=1:1000
    %% on check-nodes
    for j=1:mq% for each check node
        k = 1:rw(j);
        tmp = qa(j,k,1) - qa(j,k,2);
        sumz = sum(tmp==0);
        if sumz==0
            ra(j,k,1) = 0.5*(1+(1-2*s(j))*prod(tmp)./tmp);
        else
            ra(j,k,1) = 0.5;
            if sumz==1   % only one zero
                ra(j,tmp==0,1) = 0.5*(1+(1-2*s(j))*prod(tmp(tmp~=0)));
            end
        end
        ra(j,k,2) = 1 - ra(j,k,1);
    end

    %% on variable-nodes
    expmfb = ones(nq,2);    % extrinsic belief of variable bit nodes
    for i=1:nq
        for k=1:cw(i)
            expmfb(i,:) = expmfb(i,:) .* reshape(ra(cr(i,k),cN(i,k),:), [1,2]);
        end
    end
    rowsum = sum(expmfb,2);
    expmfb(rowsum~=0,:) = bsxfun(@rdivide, expmfb(rowsum~=0,:), rowsum(rowsum~=0)); 
    expmfb(rowsum==0,:) = 0.5;
    expmfQ = pmfb2Q(expmfb,Q);  % extrinsic belief of Q-ary nodes  
    pmfQ = inpmfQ .* expmfQ;    % overall belief of Q-ary nodes
    rowsum = sum(pmfQ,2);
    pmfQ(rowsum~=0,:) = bsxfun(@rdivide, pmfQ(rowsum~=0,:), rowsum(rowsum~=0));
    pmfQ(rowsum==0,:) = 1/Q;
    pmfb = pmfQ2b(pmfQ);    % overall belief of variable bit nodes
    
    %% hard decision and syndrome check
    xbrr = (pmfb(:,2)>pmfb(:,1));
    if any(xbr~=xbrr)
        xbr = xbrr;
        if all(s==enc(xbr,rw,rc))
            mode = 0;   % correct
            xr = bi2de(reshape(xbr,[q,n])');
            return;
        else
            nss = 0;
        end
    else
        if nss>8
            xr = y;
            mode = 1;   % bad convergence
            return;
        else
            nss = nss+1;
        end        
    end
        
    %% renew edges from varialbes to checks
    for i=1:nq
        for k=1:cw(i)
            cRa(k,:) = reshape(ra(cr(i,k),cN(i,k),:), [1,2]);
        end
        for k=1:cw(i)
            if (cRa(k,1)*cRa(k,2))~=0
                tmp = pmfb(i,:) ./ cRa(k,:);
            else
                tmp = inpmfb(i,:) .* prod(cRa((1:cw(i))~=k,:));
            end
            if sum(tmp)>0
                qa(cr(i,k),cN(i,k),:) = tmp/sum(tmp);
            else
                qa(cr(i,k),cN(i,k),:) = 0.5;
            end        
        end        
    end
end

%% doesn't converge
xr = y;
mode = 2; % slow convergence
return;