clc; clear;
rng('default');
addpath share/gf share/ntt codes;

%% rw: row weight; cw: col weight 
[rc, cr, rw, cw, rN, cN] = loadTG('reg2.75.40.txt');
[n, cwmax] = size(cr);
[m, rwmax] = size(rc);

%% code ary
q = 8;
Q = 2^q;
H = randi(Q-1, size(rc));

%% for Q-ary operations and FFT
sft = nttsft(Q);
add = gfadd(Q);
mul = gfmul(Q);

%% channel mode
chl = 'lap';
par = 2.5*73*40/(75*38); % b for Laplace distribution; sigma^2 for Gaussian distribution

%% multicores
cls = parcluster;
pool = gcp;
if isempty(pool)
    pool = parpool(cls.NumWorkers);
end
nw = pool.NumWorkers;   % number of workers
%% statistical quantities
aln = zeros(1,nw);      % average loop number
mme = zeros(1,nw);      % mean Manhattan error
fer = zeros(1,nw);      % frame-error-rate
nts = zeros(1,nw);      % number of tests
NEF = 25;

%% running 
tic;   
parfor c=1:nw
    while 1
        x = randi(Q,[1,n]) - 1;
        if strcmp(chl,'lap')
            z = par .* (log(rand(1,n)) - log(rand(1,n)));   % par = b
        elseif strcmp(chl,'gau')
            z = sqrt(par) .* randn([1,n]);  % par = sigma^2
        else
            z = [];
        end
        y = min(Q-1, max(0, round(x+z)));

        s = enc(x, rw, rc, H, q);
        [xr, mode, loop] = dec(par, y, s, rc, cr, rw, cw, cN, H, sft, mul, add, chl);

        err = mae(xr-x);
        mme(c) = mme(c) + err;
        fer(c) = fer(c) + (err>0);
        aln(c) = aln(c) + loop;
        nts(c) = nts(c) + 1;        
        if fer(c)>=NEF
            break;
        end    
    end
end
toc;

disp(sum(mme)/sum(nts));
disp(sum(fer)/sum(nts));
disp(sum(aln)/sum(nts));