function s = enc(x, rw, rc, H, q)
m = length(rw);
s = zeros(1,m);
for j=1:m
    k = 1:rw(j);
    t = gf(x(rc(j,k)),q) * gf(H(j,k)',q);
    s(j) = t.x;
end