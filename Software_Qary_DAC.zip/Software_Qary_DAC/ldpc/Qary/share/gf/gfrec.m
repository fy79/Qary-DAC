function tab = gfrec(Q)
q = log2(Q);
tab = 1./gf((1:(Q-1)),q);
tab = tab.x;