function add = gfadd(Q)
q = log2(Q);
tmp = gf(ones(Q,1)*(0:(Q-1)), q);
tmp = tmp' + tmp;
add = tmp.x + 1;
