function mul = gfmul(Q)
q = log2(Q);
tmp = gf((1:(Q-1))',q) * gf(0:(Q-1),q);
mul = tmp.x + 1;
