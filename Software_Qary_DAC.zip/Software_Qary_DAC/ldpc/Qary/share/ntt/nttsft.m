function sft = nttsft(Q)
q = log2(Q);
tmp = 0:(Q/2-1);
sft = zeros(q,Q);
for i=0:(q-1)
    msb = 2^(i+1)*fix(tmp/2^i);
    lsb = mod(tmp,2^i);
    sft(i+1, 1:(Q/2)) = msb + lsb + 1;    
    sft(i+1, (1+Q/2):Q) = sft(i+1, 1:(Q/2)) + 2^i;
end
