function y = ntt(x,r)
y = x;
d = size(r);
for b=1:d(1)
    r1 = r(b, 1:(d(2)/2));
    r2 = r(b, (1+d(2)/2):d(2));
    y(r1) = y(r1) + y(r2);
    y(r2) = y(r1) - 2*y(r2);
end