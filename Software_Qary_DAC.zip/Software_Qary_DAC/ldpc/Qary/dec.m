function [xr, mode, loop] = dec(par, y, s, rc, cr, rw, cw, cN, H, sft, mul, add, chl)

n = length(y);
m = length(s);
rwmax = max(rw);
cwmax = max(cw);
[q,Q] = size(sft);

xr = y;
sr = enc(xr, rw, rc, H, q);
if all(s==sr)
    mode = 0;  
    loop = 0;
    return;
end

if strcmp(chl,'lap')
    b = par;
    pmfin = initl(b, y, Q, 0);
elseif strcmp(chl,'gau')
    s2 = par;
    pmfin = initn(s2, y, Q, 0);
else
end

qa = zeros(m,rwmax,Q);
ra = zeros(m,rwmax,Q); 
for i=1:n 
    for k=1:cw(i)
        qa(cr(i,k),cN(i,k),:) = pmfin(i,:);
    end
end
fQa = zeros(rwmax,Q);
cRa = zeros(cwmax,Q);

nss = 0;
for loop=1:100
    %% on s-nodes
    for j=1:m
        prod = ones(1,Q);
        
        % from x-nodes
        for k=1:rw(j)
            fQa(k,mul(H(j,k),:)) = qa(j,k,:);
            fQa(k,:) = ntt(fQa(k,:),sft);
            prod = prod .* fQa(k,:);
        end
        
        % to x-nodes
        for k=1:rw(j)
            fRa = prod./fQa(k,:);
            
            %% Added below to avoid zero denominator 
            for i=1:Q
                if fQa(k,i)==0
                    fRa(i) = 1;
                    for kk=1:(k-1)
                        fRa(i) = fRa(i) * fQa(kk,i);
                    end
                    for kk=(k+1):rw(j)
                        fRa(i) = fRa(i) * fQa(kk,i);
                    end
                end
            end
            %% Added above to avoid zero denominator
            
            fRa = ntt(fRa,sft);
            ra(j,k,:) = fRa(add(s(j)+1, mul(H(j,k),:)))/Q;
        end
    end

    %% on x-nodes
    nds = 0;
    for i=1:n 
        prod = pmfin(i,:);
        
        % from s-nodes
        for k=1:cw(i)
            cRa(k,:) = reshape(ra(cr(i,k),cN(i,k),:),[1,Q]);
            prod = prod .* cRa(k,:);
        end
        
        % to s-nodes
        for k=1:cw(i)
            tmp = prod ./ cRa(k,:);            
            
            %% Added below to avoid zero denominator 
            for j=1:Q
                if cRa(k,j)==0
                    tmp(j) = pmfin(i,j);
                    for kk=1:(k-1)
                        tmp(j) = tmp(j) * cRa(kk,j);
                    end
                    for kk=(k+1):cw(i)
                        tmp(j) = tmp(j) * cRa(kk,j);
                    end
                end
            end
            %% Added above to avoid zero denominator
            
            tot = sum(tmp);
            
            %% Added below to avoid zero denominator 
            if tot>0
                qa(cr(i,k),cN(i,k),:) = tmp/sum(tmp);
            else
                qa(cr(i,k),cN(i,k),:) = 1/Q;
            end
            %% Added above to avoid zero denominator            
        end
        
        % hard decision
        [~,argmaxa] = max(prod);
        if xr(i)~=(argmaxa-1)
            xr(i) = (argmaxa-1);
            nds = nds + 1;
        end
    end

    %% convergence test
    if nds
        sr = enc(xr, rw, rc, H, q);
        if all(s==sr)
            mode = 0;   % good convergence
            return;
        else
            nss = 0;
        end
    else
        if nss>3
            xr = y;
            mode = 1;   % bad convergence
            return; 
        else
            nss = nss+1;
        end
    end
end

xr = y;
mode = 2; % slow convergence
return;