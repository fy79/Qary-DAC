function pmfin = initl(b,y,Q,LB)
n = length(y);
assert(length(b)==1 || length(b)==n);
pmfin = zeros(n,Q);
for i=1:n
    z = (0:(Q-1)) - y(i);
    if length(b)==1
        tmp = max(LB, exp(-abs(z)/b));
    else
        tmp = max(LB, exp(-abs(z)/b(i)));
    end
    pmfin(i,:) = tmp/sum(tmp);  
end    
