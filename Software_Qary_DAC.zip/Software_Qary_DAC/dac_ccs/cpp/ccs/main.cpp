#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
#include <stdint.h>
using namespace std;

// parameters to control the AC codec
const unsigned DEPTH = 32;
const unsigned HRANGE = (1<<(DEPTH-1));// half of the range
const unsigned QRANGE = (1<<(DEPTH-2));// quarter of the range
const unsigned MASK = (HRANGE|(HRANGE-1));

uint8_t src[BUFSIZ], str[8*BUFSIZ];
int **freq;
const int NSEGS = (1<<10);
const int N = 73;    // frame length
const int ntries = (NSEGS<<10); // number of trials
// (3,2), (5,4), (7,2), (9,8)
const unsigned SNUM = 256;
const unsigned RNUM = 16;
struct INTVL {double l; double h;};
INTVL spans[SNUM];
void initialize_intervals(void){
    for(int i=0; i<SNUM; i++){
        spans[i].l = i/double(SNUM+RNUM-1);
        spans[i].h = (i+RNUM)/double(SNUM+RNUM-1);
    }
}

// encode one source symbol
void encode_symbol(uint8_t *str, unsigned &low, unsigned &high, int &nuf, int &ptr, int x){
    unsigned range = high - low;
    high = low + unsigned(ceil(range*spans[x].h - 1.0 + spans[x].h));
    low += unsigned(floor(range*spans[x].l + spans[x].l));
        
    /* If this test passes, the MSDigits match and can be sent to the output stream. */
    while(!((low^high)&HRANGE)){
        uint8_t msb = ((low&HRANGE)>0);
        str[ptr++] = msb;
        while(nuf){
            str[ptr++] = !msb;
            nuf--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
//    low &= MASK; high &= MASK; // this line is unnecessary if DPETH=32

    /* If this test passes, the numbers are in danger of underflow. */
    while((high&QRANGE)<(low&QRANGE)){
        low  -= QRANGE; low  <<= 1;
        high -= QRANGE; high <<= 1; high |= 1;
        nuf++;
    }
}

int encode(uint8_t* str, uint8_t* src, int N) {
    memset(str, 0, 8*BUFSIZ*sizeof(uint8_t));
    unsigned low=0, high=MASK; int nuf=0, ptr=0;
    for(int i=0; i<N; i++){
        encode_symbol(str, low, high, nuf, ptr, int(src[i]));
    }
    str[ptr] = 1;
    return ptr;
}

// remove the source symbol from the buffer
void remove_symbol(uint8_t* str, unsigned &low, unsigned &high, unsigned &code, int &ptr, int x){
    unsigned range = high - low;
    high = low + unsigned(ceil(range*spans[x].h - 1.0 + spans[x].h));
    low += unsigned(floor(range*spans[x].l + spans[x].l));

    /* If the MSDigits match, the bits will be shifted out. */
    while(!((low^high)&HRANGE)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
//    low &= MASK; high &= MASK; code &= MASK; // this line is unnecessary if DPETH=32

    /* If underflow is threatening, shift out the 2nd MSDigit. */
    while((high&QRANGE)<(low&QRANGE)){
        low  -= QRANGE; low  <<= 1;
        high -= QRANGE; high <<= 1; high |= 1;
        code -= QRANGE; code <<= 1; code |= str[ptr++];
    }
}

void decode(uint8_t* str, uint8_t* src, int N) {
	unsigned low=0, high=MASK, code=0; int ptr=0;
    for(int i=0; i<DEPTH; i++){
        code <<= 1;
        code |= str[ptr++];
    }
	for(int i=0; i<=N; i++){
		double u = (code-low)/(double(high-low)+1.0);
		freq[i][unsigned(u*NSEGS)]++;
        if(i<N){
            remove_symbol(str,low, high, code, ptr, int(src[i]));
        }
	}
}

int main(int argc, char *argv[]){
    freq = new int*[N+1];
    for(int i=0; i<=N; i++){
        freq[i] = new int[NSEGS];
        memset(freq[i], 0, sizeof(int)*NSEGS);
    }
    initialize_intervals();  // initialize intervals

    double R = 0.0;
    srand(0);//unsigned(time(0)));
    for(int t=0; t<ntries; t++){
        for(int i=0; i<N; i++){
            src[i] = (rand()%SNUM);
        }
        R += encode(str, src, N)/(double)N;
        decode(str, src, N);
    }
    cout<<"bps = "<<(R/ntries)/log2(SNUM)<<endl;
    
    FILE *fp = fopen("../../../../../matlab/par.txt", "wt");//please revise file path if needed
    if(fp==NULL){
        cout<<"File open fails!"<<endl;
    }else{
        fprintf(fp, "%d\n%d\n", SNUM, RNUM);
        fclose(fp);
    }

    fp = fopen("../../../../../matlab/u.txt", "wt");//please revise file path if needed
    if(fp==NULL){
        cout<<"File open fails!"<<endl;
        return 1;
    }else{
        for(int i=0; i<=N; i++){
            for(int u=0; u<NSEGS; u++){
                fprintf(fp, "%f\t", (freq[i][u]/double(ntries))*NSEGS);
            }
            fprintf(fp, "\n");
        }
        fclose(fp);
        return 0;
    }
}
