clc; clear;

t = 0; % we fix tail length to zero
par = load('par.txt');
snum = par(1);
rnum = par(2);
ccsexp = load('u.txt');
[n,N] = size(ccsexp);
n = n-1;    % frame length
num = (snum+rnum-1);
delta = 1/(snum+rnum-1);
lbs = ceil((0:(snum-1))*delta*N) + 1;       % lower bounds
ubs = ceil((rnum:(rnum+snum-1))*delta*N);   % upper bounds
tau = n*log2(delta) - floor(n*log2(delta));
ccs = dac_ccs_uniform(n,N,lbs,ubs,tau);
plot((0:(N-1))/N, ccsexp(1,:)); hold on;
plot((0:(N-1))/N, ccs(1,:));
line([0,(rnum-1)/num,snum/num,1], [0,num/snum,num/snum,0], 'color', 'green');

grid on;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_0(u)$'}, 'interpreter', 'latex');

title({'$Q=256$, $\tau=16/271$, $\lambda(x)=x/271$, $n=73$'}, 'interpreter', 'latex');
% title({'$Q=256$, $\tau=64/319$, $\lambda(x)=x/319$, $n=128$'}, 'interpreter', 'latex');
% title({'$Q=5$, $rq=1$, $\lambda(x)=x/8$'}, 'interpreter', 'latex');
% title({'$Q=7$, $rq=2$, $\lambda(x)=x/8$'}, 'interpreter', 'latex');
% title({'$Q=9$, $rq=1$, $\lambda(x)=x/16$'}, 'interpreter', 'latex');

legend({'Experimental', 'Numerical', 'Approximation'}, 'interpreter', 'latex', 'location', 'best');
% legend({'Experimental', 'Theoretical'}, 'interpreter', 'latex', 'location', 'best');

set(gca,'FontSize',16);