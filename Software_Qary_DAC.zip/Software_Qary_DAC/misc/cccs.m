Q=12;
B=3;
K=Q+B-1;

line([0,(B-1)/K,Q/K,1]*B/K,     [0,K/Q,K/Q,0]*K/B);
line([0,(B-1)/K,Q/K,1]*B/K+1/K, [0,K/Q,K/Q,0]*K/B, 'color', 'red');
line([0,(B-1)/K,Q/K,1]*B/K+2/K, [0,K/Q,K/Q,0]*K/B, 'color', 'green');
line([0,(B-1)/K,Q/K,1]*B/K+3/K, [0,K/Q,K/Q,0]*K/B);
line([0,(B-1)/K,Q/K,1]*B/K+4/K, [0,K/Q,K/Q,0]*K/B, 'color', 'red');
line([0,(B-1)/K,Q/K,1]*B/K+5/K, [0,K/Q,K/Q,0]*K/B, 'color', 'green');
line([0,(B-1)/K,Q/K,1]*B/K+6/K, [0,K/Q,K/Q,0]*K/B);
line([0,(B-1)/K,Q/K,1]*B/K+7/K, [0,K/Q,K/Q,0]*K/B, 'color', 'red');
line([0,(B-1)/K,Q/K,1]*B/K+8/K, [0,K/Q,K/Q,0]*K/B, 'color', 'green');
line([0,(B-1)/K,Q/K,1]*B/K+9/K,  [0,K/Q,K/Q,0]*K/B);
line([0,(B-1)/K,Q/K,1]*B/K+10/K, [0,K/Q,K/Q,0]*K/B, 'color', 'red');
line([0,(B-1)/K,Q/K,1]*B/K+11/K, [0,K/Q,K/Q,0]*K/B, 'color', 'green');

grid on;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'approximated $f_{i|i+1}(u|x)$'}, 'interpreter', 'latex');
title({'$Q=ab=12$, $a=4$, and $b=3$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);