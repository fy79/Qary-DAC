d=0:1e-3:(1-1e-3);
plot(d,d); hold on;
plot(d,2.^d-1);
plot(d,d-2.^d+1);
grid on;
xlabel({'$\delta=\lceil{nrq}\rceil-nrq$'}, 'interpreter', 'latex');
legend({'$\delta$', '$2^{\delta}-1$', '$-h(U_n)$'}, 'interpreter', 'latex','location','best');
set(gca,'fontsize',16);