function b = getbmax(r,Q, mode)
% b: the maximal benchmark scale parameter for a given rate r
% r=38*8/73 or 180*8/353, and Q=256
if mode
    b = fsolve(@(b)calentropy_accurate(b,r,Q), 3);
else    
    b = fsolve(@(b)calentropy_asymptotic(b,r), 3);
end
end

function r = calentropy_accurate(b,r,Q)
a = exp(-1/b);
x = 0:(Q-1);
for y=(0:(Q-1))
    alpha = (1-a)./((1+a)-(a.^(Q+x)+a.^(x+1)));
    pyonx = alpha .* a.^(abs(y-x));    
    pxy = pyonx/Q;
    py = sum(pxy);
    r = r - sum(pxy.*log2(py./pxy));
end
end

function r = calentropy_asymptotic(b,r)
a = exp(-1/b);
r = r+log2((1-a)./(1+a)) + (2*a./(1-a.*a)).*log2(a);
end

