figure(1);
stem(0:11,[1,zeros(1,11)]); grid on;
xlabel({'$\delta$'}, 'interpreter', 'latex');
ylabel({'$\phi(\delta)$ of ${\cal I}_0$'}, 'interpreter', 'latex');
title({'$a=4$, $b=3$, and $Q=ab=12$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);

figure(2);
stem(0:11,[2,0,0,0,1,zeros(1,7)]); grid on;
xlabel({'$\delta$'}, 'interpreter', 'latex');
ylabel({'$\phi(\delta)$ of ${\cal I}_1$'}, 'interpreter', 'latex');
title({'$a=4$, $b=3$, and $Q=ab=12$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);

figure(3);
stem(0:11,[3,0,0,0,2,0,0,0,1,zeros(1,3)]); grid on;
xlabel({'$\delta$'}, 'interpreter', 'latex');
ylabel({'$\phi(\delta)$ of ${\cal I}_2$'}, 'interpreter', 'latex');
title({'$a=4$, $b=3$, and $Q=ab=12$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);

figure(4);
stem(0:11,[3,0,0,1,1,0,0,1,0,zeros(1,3)]); grid on;
xlabel({'$\delta$'}, 'interpreter', 'latex');
ylabel({'$\phi(\delta)$ of ${\cal I}_3$'}, 'interpreter', 'latex');
title({'$a=4$, $b=3$, and $Q=ab=12$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);